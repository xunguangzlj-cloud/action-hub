'use strict';

const crypto = require('crypto');
const db = uniCloud.database();
const stateDocument = db.collection('action-hub-state').doc('primary');

function response(statusCode, data) {
  return {
    mpserverlessComposedResponse: true,
    isBase64Encoded: false,
    statusCode,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'access-control-allow-origin': '*',
      'access-control-allow-methods': 'POST, OPTIONS',
      'access-control-allow-headers': 'content-type',
      'cache-control': 'no-store'
    },
    body: JSON.stringify(data)
  };
}

function sameSecret(received, expected) {
  if (!received || !expected) return false;
  const left = crypto.createHash('sha256').update(String(received)).digest();
  const right = crypto.createHash('sha256').update(String(expected)).digest();
  return crypto.timingSafeEqual(left, right);
}

function newerTask(left, right) {
  return new Date(left?.updatedAt || 0) >= new Date(right?.updatedAt || 0) ? left : right;
}

function mergeTasks(localTasks, cloudTasks) {
  const merged = new Map();
  for (const task of [...cloudTasks, ...localTasks]) {
    if (!task || typeof task.id !== 'string' || typeof task.title !== 'string') continue;
    merged.set(task.id, merged.has(task.id) ? newerTask(task, merged.get(task.id)) : task);
  }
  return [...merged.values()];
}

function canonicalJson(value) {
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(',')}]`;
  if (value && typeof value === 'object') {
    return `{${Object.keys(value).sort().map(key => `${JSON.stringify(key)}:${canonicalJson(value[key])}`).join(',')}}`;
  }
  return JSON.stringify(value);
}

function sameTasks(left, right) {
  if (left.length !== right.length) return false;
  const byId = tasks => [...tasks].sort((a, b) => a.id.localeCompare(b.id));
  return canonicalJson(byId(left)) === canonicalJson(byId(right));
}

exports.main = async (event) => {
  if (event.httpMethod === 'OPTIONS') return response(204, {});
  if (event.httpMethod !== 'POST') return response(405, { error: '仅支持 POST 请求' });

  try {
    const bodyText = event.isBase64Encoded
      ? Buffer.from(event.body || '', 'base64').toString('utf8')
      : event.body || '{}';
    const body = JSON.parse(bodyText);
    if (!sameSecret(body.syncKey, process.env.ACTION_HUB_SYNC_KEY)) {
      return response(401, { error: '同步密钥不正确' });
    }
    const incomingTasks = body.protocol === 2 ? body.changes : body.tasks;
    if (!Array.isArray(incomingTasks) || incomingTasks.length > 10000) {
      return response(400, { error: '任务数据格式不正确' });
    }

    const result = await stateDocument.get();
    const cloudState = result.data?.[0] || {};
    const cloudTasks = cloudState.tasks || [];
    const cloudRevision = Number(cloudState.revision) || 0;
    const tasks = mergeTasks(incomingTasks, cloudTasks);
    if (sameTasks(tasks, cloudTasks)) {
      if (body.protocol === 2 && body.revision === cloudRevision) {
        return response(200, { revision: cloudRevision, updatedAt: cloudState.updatedAt || '', changed: false, full: false });
      }
      return response(200, { tasks: cloudTasks, revision: cloudRevision, updatedAt: cloudState.updatedAt || '', changed: false, full: true });
    }
    const updatedAt = new Date().toISOString();
    const revision = cloudRevision + 1;
    await stateDocument.set({ tasks, updatedAt, revision });
    return response(200, { tasks, revision, updatedAt, changed: true, full: true });
  } catch (error) {
    console.error(error);
    if (/quota|limit|exceed|write|WU|额度|资源/i.test(String(error?.message || error))) {
      return response(429, { error: '免费云数据库今日写入额度已用完，请次日再同步。' });
    }
    return response(500, { error: '云端同步失败' });
  }
};
