const KEY='action-hub-v1';
const CLOUD_KEY='action-hub-cloud-cn-v2';
const CLOUD_DIRTY_KEY='action-hub-cloud-dirty-v1';
const CLOUD_VERSIONS_KEY='action-hub-cloud-versions-v1';
const LAST_BACKUP_KEY='action-hub-last-backup-v1';
const REVIEW_RECORD_ID='action-hub-weekly-review';
const QUICK_CAPTURE_FOLDER_ID='action-hub-quick-capture';
const NATIVE_REMINDERS_KEY='action-hub-native-reminders-v1';
const notificationTimers=new Map();
let nativePermissionRequested=false;
const WORKFLOW_STAGES=[
  {key:'capture',title:'收集',id:'action-hub-stage-capture'},
  {key:'clarify',title:'明确',id:'action-hub-stage-clarify'},
  {key:'act',title:'行动',id:'action-hub-stage-act'}
];
const AUTO_SYNC_DELAY=60000;
const STARTUP_SYNC_INTERVAL=60*60*1000;
const state={tasks:JSON.parse(localStorage.getItem(KEY)||'[]'),view:'inbox',folderSelection:{inbox:'all',planned:'all'},searchQuery:'',timeLimit:0,batchDelete:false,selectedCompleted:new Set(),deferredPrompt:null,syncing:false,syncTimer:null,retryTimer:null,syncRetries:0};
const $=id=>document.getElementById(id);
const dateValue=date=>`${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`;
const today=()=>dateValue(new Date());
const now=()=>new Date().toISOString();
const uid=()=>crypto.randomUUID?crypto.randomUUID():Date.now().toString(36);
const touch=task=>task.updatedAt=now();
const persist=()=>localStorage.setItem(KEY,JSON.stringify(state.tasks));
function save(sync=true){persist();$('saveStatus').textContent='本机已保存';render();scheduleNotifications();if(sync){localStorage.setItem(CLOUD_DIRTY_KEY,'1');queueSync()}}
const formatDate=v=>v?new Intl.DateTimeFormat('zh-CN',{month:'numeric',day:'numeric'}).format(new Date(v+'T00:00')):'';

function normalizeTasks(){
  let changed=false;
  for(const task of state.tasks){if(!task.createdAt){task.createdAt=task.updatedAt||now();changed=true}if(!task.updatedAt){task.updatedAt=task.createdAt;changed=true}if(task.deletedAt===undefined){task.deletedAt='';changed=true}if(task.kind==='folder'){if(task.parentId===undefined){task.parentId='';changed=true}continue}if(task.kind==='system')continue;if(task.location===undefined){task.location=task.attachment?.location||'';changed=true}if(task.folderId===undefined){task.folderId='';changed=true}if(task.state==='waiting'){task.state='inbox';task.folderId='';touch(task);changed=true}}
  if(ensureWorkflowFolders())changed=true;
  if(ensureQuickCaptureFolder())changed=true;
  for(const folder of state.tasks.filter(t=>t.kind==='folder'&&!t.deletedAt)){const parent=folderById(folder.parentId);if(folder.parentId&&(!parent||parent.scope!==folder.scope||isFolderDescendant(folder.parentId,folder.id))){folder.parentId='';touch(folder);changed=true}}
  if(changed)persist();
  return changed;
}
function ensureWorkflowFolders(){
  let changed=false;
  for(const stage of WORKFLOW_STAGES){
    let folder=state.tasks.find(t=>t.kind==='folder'&&(t.id===stage.id||t.workflowStage===stage.key||(!t.deletedAt&&t.scope==='planned'&&!t.parentId&&t.title===stage.title)));
    if(!folder){const stamp=now();folder={id:stage.id,kind:'folder',scope:'planned',parentId:'',title:stage.title,workflowStage:stage.key,createdAt:stamp,updatedAt:stamp,deletedAt:''};state.tasks.push(folder);changed=true;continue}
    const expected={scope:'planned',parentId:'',title:stage.title,workflowStage:stage.key,deletedAt:''};let folderChanged=false;
    for(const [key,value] of Object.entries(expected))if(folder[key]!==value){folder[key]=value;folderChanged=true}
    if(folderChanged){touch(folder);changed=true}
  }
  return changed;
}
function ensureQuickCaptureFolder(){
  const expected={kind:'folder',scope:'inbox',parentId:'',title:'一句话记录',deletedAt:''};let folder=state.tasks.find(t=>t.id===QUICK_CAPTURE_FOLDER_ID);
  if(!folder){const stamp=now();state.tasks.push({id:QUICK_CAPTURE_FOLDER_ID,...expected,createdAt:stamp,updatedAt:stamp});return true}
  let changed=false;for(const [key,value] of Object.entries(expected))if(folder[key]!==value){folder[key]=value;changed=true}
  if(changed)touch(folder);return changed;
}
function isQuickCapture(task){return task.state==='inbox'&&task.folderId===QUICK_CAPTURE_FOLDER_ID}
function recordQuickCapture(){
  const input=$('quickCaptureInput'),title=input.value.trim();if(!title){input.focus();return}
  ensureQuickCaptureFolder();const stamp=now();state.tasks.push({id:uid(),title,location:'',state:'inbox',folderId:QUICK_CAPTURE_FOLDER_ID,priority:'',date:'',time:'',duration:30,reminder:'',notes:'',completedAt:'',deletedAt:'',createdAt:stamp,updatedAt:stamp});
  state.searchQuery='';$('searchInput').value='';state.view='inbox';state.folderSelection.inbox=QUICK_CAPTURE_FOLDER_ID;save();input.value='';$('quickCaptureStatus').textContent='已记录到“一句话记录”';input.focus();
}
function folders(scope){return state.tasks.filter(t=>t.kind==='folder'&&!t.deletedAt&&t.scope===scope).sort((a,b)=>Number(b.id===QUICK_CAPTURE_FOLDER_ID)-Number(a.id===QUICK_CAPTURE_FOLDER_ID)||workflowStageRank(a)-workflowStageRank(b)||a.title.localeCompare(b.title,'zh-CN'))}
function workflowStageRank(folder){const index=WORKFLOW_STAGES.findIndex(stage=>stage.key===folder.workflowStage);return index<0?WORKFLOW_STAGES.length:index}
function folderById(id){return state.tasks.find(t=>t.kind==='folder'&&!t.deletedAt&&t.id===id)}
function isFolderDescendant(candidateId,ancestorId){let current=folderById(candidateId);const seen=new Set();while(current&&!seen.has(current.id)){if(current.id===ancestorId)return true;seen.add(current.id);current=folderById(current.parentId)}return false}
function descendantFolderIds(folderId){return new Set(folders(folderById(folderId)?.scope).filter(f=>isFolderDescendant(f.id,folderId)).map(f=>f.id))}
function flattenFolders(scope,excluded=new Set()){const available=folders(scope).filter(f=>!excluded.has(f.id)),ids=new Set(available.map(f=>f.id)),children=new Map();for(const folder of available){const parent=ids.has(folder.parentId)?folder.parentId:'';if(!children.has(parent))children.set(parent,[]);children.get(parent).push(folder)}const result=[],visited=new Set();function append(parentId,depth){for(const folder of children.get(parentId)||[]){if(visited.has(folder.id))continue;visited.add(folder.id);result.push({folder,depth});append(folder.id,depth+1)}}append('',0);for(const folder of available)if(!visited.has(folder.id)){result.push({folder,depth:0});append(folder.id,1)}return result}
function folderPath(id){const names=[],seen=new Set();let folder=folderById(id);while(folder&&!seen.has(folder.id)){names.unshift(folder.title);seen.add(folder.id);folder=folderById(folder.parentId)}return names.join(' / ')}
function selectedFolderId(scope){const id=state.folderSelection[scope];return id&&!['all','priority','unfiled','unlocated'].includes(id)&&folderById(id)?.scope===scope?id:''}
function taskFolderId(task){return folderById(task.folderId)?.scope===task.state?task.folderId:''}
function workflowFolder(stage){return folders('planned').find(folder=>folder.workflowStage===stage)}
function taskInWorkflowStage(task,stage){const root=workflowFolder(stage);return task.state==='planned'&&!!root&&isFolderDescendant(taskFolderId(task),root.id)}
function workflowStageCount(stage){return activeTasks().filter(task=>!task.completedAt&&taskInWorkflowStage(task,stage)).length}
function openWorkflowStage(stage){state.searchQuery='';$('searchInput').value='';state.view='planned';state.folderSelection.planned=workflowFolder(stage)?.id||'all';render()}
function activeTasks(){return state.tasks.filter(t=>(!t.kind||t.kind==='task')&&!t.deletedAt)}
function recentLocations(){const seen=new Set(),result=[];for(const task of [...activeTasks()].sort((a,b)=>(b.updatedAt||'').localeCompare(a.updatedAt||''))){const location=String(task.location||'').trim(),key=location.toLocaleLowerCase('zh-CN');if(!location||seen.has(key))continue;seen.add(key);result.push(location);if(result.length===50)break}return result}
function setupLocationAutocomplete(inputId,menuId){
  const input=$(inputId),menu=$(menuId),field=input.closest('.location-autocomplete');let matches=[],activeIndex=-1;
  function close(){menu.hidden=true;menu.innerHTML='';field.classList.remove('open');input.setAttribute('aria-expanded','false');activeIndex=-1}
  function choose(value){input.value=value;input.dispatchEvent(new Event('input',{bubbles:true}));close();input.focus()}
  function paint(){menu.innerHTML='';for(const [index,value] of matches.entries()){const button=document.createElement('button'),mark=document.createElement('span'),text=document.createElement('span');button.type='button';button.className='location-option';button.setAttribute('role','option');button.setAttribute('aria-selected',String(index===activeIndex));button.classList.toggle('active',index===activeIndex);mark.className='location-option-mark';mark.setAttribute('aria-hidden','true');text.textContent=value;button.append(mark,text);button.onmousedown=e=>e.preventDefault();button.onclick=()=>choose(value);menu.appendChild(button)}menu.hidden=!matches.length;field.classList.toggle('open',!!matches.length);input.setAttribute('aria-expanded',String(!!matches.length));menu.querySelector('.active')?.scrollIntoView({block:'nearest'})}
  function update(){const query=input.value.trim().toLocaleLowerCase('zh-CN'),locations=recentLocations();matches=(query?locations.filter(value=>value.toLocaleLowerCase('zh-CN').includes(query)).sort((a,b)=>Number(!a.toLocaleLowerCase('zh-CN').startsWith(query))-Number(!b.toLocaleLowerCase('zh-CN').startsWith(query))):locations).slice(0,8);activeIndex=-1;matches.length?paint():close()}
  input.addEventListener('focus',update);input.addEventListener('input',update);input.addEventListener('blur',()=>setTimeout(close,150));
  input.addEventListener('keydown',e=>{if(e.key==='Escape'){close();return}if(!['ArrowDown','ArrowUp','Enter'].includes(e.key))return;if(e.key==='Enter'&&activeIndex<0)return;if(!matches.length)update();if(!matches.length)return;if(e.key==='Enter'){e.preventDefault();choose(matches[activeIndex]);return}e.preventDefault();activeIndex=e.key==='ArrowDown'?(activeIndex+1)%matches.length:(activeIndex-1+matches.length)%matches.length;paint()});
  document.addEventListener('pointerdown',e=>{if(!field.contains(e.target))close()});
}
function applyTimeFilter(tasks){return state.timeLimit&&['planned','today'].includes(state.view)?tasks.filter(t=>Number(t.duration||30)<=state.timeLimit):tasks}
function taskSearchText(task){return [task.title,task.location,task.notes,task.attachment?.name,task.attachment?.type,folderPath(taskFolderId(task)),task.state==='planned'?'行动计划':'收集箱',task.completedAt?'完成记录':''].filter(Boolean).join(' ').toLocaleLowerCase('zh-CN')}
function filteredTasks(){
  const all=activeTasks();
  const query=state.searchQuery.trim().toLocaleLowerCase('zh-CN');if(query)return all.filter(task=>taskSearchText(task).includes(query)).sort((a,b)=>Number(!!a.completedAt)-Number(!!b.completedAt)||sortPriorityTasks(a,b));
  if(state.view==='inbox'&&state.folderSelection.inbox===QUICK_CAPTURE_FOLDER_ID)return all.filter(isQuickCapture).sort(sortPriorityTasks);
  const existing=all.filter(task=>!isQuickCapture(task));
  if(state.view==='completed')return existing.filter(t=>t.completedAt).sort((a,b)=>b.completedAt.localeCompare(a.completedAt));
  const active=existing.filter(t=>!t.completedAt);
  if(state.view==='today')return applyTimeFilter(active.filter(t=>t.date===today()).sort(sortPriorityTasks));
  const selected=state.folderSelection[state.view];if(selected==='priority')return applyTimeFilter(active.filter(t=>t.state==='inbox'||t.state==='planned').sort(sortPriorityTasks));
  if(selected==='unlocated')return applyTimeFilter(active.filter(t=>(t.state==='inbox'||t.state==='planned')&&!String(t.location||'').trim()).sort(sortPriorityTasks));
  const tasks=active.filter(t=>t.state===state.view);
  if(selected==='unfiled')return applyTimeFilter(tasks.filter(t=>!taskFolderId(t)).sort(sortPriorityTasks));
  if(selected&&selected!=='all')return applyTimeFilter(tasks.filter(t=>taskFolderId(t)===selected).sort(sortPriorityTasks));
  return applyTimeFilter(tasks.sort(sortPriorityTasks));
}
function priorityRank(task){const value=Number(task.priority);return value>=1&&value<=4?value:5}
function pinRank(a,b){return Number(!!b.pinned)-Number(!!a.pinned)}
function sortTasks(a,b){return (a.time||'99:99').localeCompare(b.time||'99:99')||priorityRank(a)-priorityRank(b)||a.createdAt.localeCompare(b.createdAt);}
function sortPriorityTasks(a,b){return pinRank(a,b)||priorityRank(a)-priorityRank(b)||(a.date||'9999-12-31').localeCompare(b.date||'9999-12-31')||(a.time||'99:99').localeCompare(b.time||'99:99')||a.createdAt.localeCompare(b.createdAt)}
function renderFolders(){
  const supported=!state.searchQuery&&(state.view==='inbox'||state.view==='planned');$('folderBar').hidden=!supported;if(!supported)return;
  const available=folders(state.view);const selected=state.folderSelection[state.view];if(!['all','priority','unfiled','unlocated'].includes(selected)&&!available.some(f=>f.id===selected))state.folderSelection[state.view]='all';
  const list=$('folderList');list.innerHTML='';const choices=[...['all','priority','unfiled','unlocated'].map(id=>({folder:{id,title:{all:'全部',priority:'优先级',unfiled:'未归类',unlocated:'未明确位置'}[id]},depth:0,special:true})),...flattenFolders(state.view).map(item=>({...item,special:false}))];
  for(const {folder,depth,special} of choices){const button=document.createElement('button'),icon=document.createElement('span'),label=document.createElement('span');button.type='button';button.className='folder-tile';button.classList.toggle('special-folder',special);button.classList.toggle('nested-folder',!special&&depth>0);button.classList.toggle('workflow-stage-folder',!!folder.workflowStage);if(folder.workflowStage)button.classList.add(`stage-${folder.workflowStage}`);button.classList.toggle('priority-folder',folder.id==='priority');button.classList.toggle('active',state.folderSelection[state.view]===folder.id);button.style.setProperty('--folder-depth',special?0:depth);icon.className=`folder-icon ${special?`icon-${folder.id}`:''}`;icon.setAttribute('aria-hidden','true');label.textContent=folder.title;button.append(icon,label);if(!special){const hint=document.createElement('span');hint.className='folder-drop-hint';hint.textContent='松开放入';button.appendChild(hint);button.title='可把电脑文件拖到此文件夹';button.setAttribute('aria-label',`${folder.title}，可拖入电脑文件`);enableFolderFileDrop(button,folder)}button.onclick=()=>{state.folderSelection[state.view]=folder.id;render()};list.appendChild(button)}
  const editable=folderById(state.folderSelection[state.view]);$('renameFolder').hidden=!editable;$('deleteFolder').hidden=!editable;
  if(editable?.workflowStage||editable?.id===QUICK_CAPTURE_FOLDER_ID){$('renameFolder').hidden=true;$('deleteFolder').hidden=true}
  $('newFolder').textContent=editable&&editable.id!==QUICK_CAPTURE_FOLDER_ID?'＋ 子文件夹':'＋ 文件夹';
}
function renderCompletedBatch(){
  const visible=state.view==='completed'&&!state.searchQuery,completed=activeTasks().filter(t=>t.completedAt&&!isQuickCapture(t));$('completedBatchBar').hidden=!visible;if(!visible)return;
  for(const id of state.selectedCompleted)if(!completed.some(t=>t.id===id))state.selectedCompleted.delete(id);
  $('startBatchDelete').hidden=state.batchDelete;$('startBatchDelete').disabled=!completed.length;$('batchControls').hidden=!state.batchDelete;$('batchSelectedCount').textContent=`已选 ${state.selectedCompleted.size} 项`;$('deleteSelectedCompleted').disabled=!state.selectedCompleted.size;$('selectAllCompleted').textContent=completed.length&&state.selectedCompleted.size===completed.length?'取消全选':'全选';
}
function renderWorkflow(){const last=state.tasks.find(t=>t.id===REVIEW_RECORD_ID&&t.kind==='system'&&!t.deletedAt)?.reviewedAt;$('flowCollectCount').textContent=`${workflowStageCount('capture')} 项`;$('flowClarifyCount').textContent=`${workflowStageCount('clarify')} 项`;$('flowActionCount').textContent=`${workflowStageCount('act')} 项`;$('flowReviewStatus').textContent=last?`${Math.floor((Date.now()-new Date(last))/86400000)} 天前完成`:'尚未回顾';document.querySelectorAll('.flow-step').forEach(button=>button.classList.remove('active'));let current='';if(state.view==='planned'){const selected=state.folderSelection.planned;current=WORKFLOW_STAGES.find(stage=>isFolderDescendant(selected,workflowFolder(stage.key)?.id))?.key||''}else if(state.view==='today')current='act';else if(state.view==='completed')current='review';document.querySelector(`[data-flow="${current}"]`)?.classList.add('active')}
function renderActionFilter(){const visible=!state.searchQuery&&['planned','today'].includes(state.view);$('actionFilter').hidden=!visible;document.querySelectorAll('[data-minutes]').forEach(button=>button.classList.toggle('active',Number(button.dataset.minutes)===state.timeLimit))}
function render(){
  const titles={inbox:['先收集，后判断','收集箱'],today:['把重要的事放进时间里','今日行动'],planned:['看清接下来要推进什么','行动计划'],completed:['做过的事都有迹可循','完成记录']};
  const tasks=filteredTasks(),searching=!!state.searchQuery;[$('viewKicker').textContent,$('viewTitle').textContent]=searching?['全局搜索',`找到 ${tasks.length} 项`]:titles[state.view];
  document.querySelectorAll('.nav-item').forEach(b=>b.classList.toggle('active',!searching&&b.dataset.view===state.view));
  const existing=activeTasks().filter(t=>!isQuickCapture(t)),active=existing.filter(t=>!t.completedAt);$('inboxCount').textContent=active.filter(t=>t.state==='inbox').length;$('todayCount').textContent=active.filter(t=>t.date===today()).length;$('plannedCount').textContent=active.filter(t=>t.state==='planned').length;$('completedCount').textContent=existing.filter(t=>t.completedAt).length;
  renderFolders();renderCompletedBatch();renderWorkflow();renderActionFilter();const list=$('taskList');list.innerHTML='';$('emptyState').hidden=tasks.length>0;$('emptyTitle').textContent=searching?'没有找到匹配内容':state.timeLimit&&['planned','today'].includes(state.view)?'当前时间内没有合适的行动':'这里已经清空';$('emptyMessage').textContent=searching?'换一个关键词，可搜索内容、位置、文件或文件夹。':state.timeLimit&&['planned','today'].includes(state.view)?'选择更长的可用时间，或先处理一项更短的行动。':'新的事情先记入收集箱，稍后再决定什么时候做。';$('clearSearch').hidden=!searching;
  for(const task of tasks){
    const node=$('taskTemplate').content.cloneNode(true),card=node.querySelector('.task-card'),complete=node.querySelector('.complete-button'),actions=node.querySelector('.task-actions'),pin=node.querySelector('.pin-button'),edit=node.querySelector('.edit-button');card.dataset.taskId=task.id;card.classList.toggle('completed',!!task.completedAt);card.classList.toggle('pinned',!!task.pinned&&!task.completedAt);node.querySelector('h3').textContent=task.title;const priority=node.querySelector('.priority'),rank=priorityRank(task);if(rank<=4){priority.classList.add(`p${rank}`);priority.textContent=`P${rank}`}else{priority.classList.add('unset');priority.textContent='未设置'}node.querySelector('.task-location').textContent=task.location||'未填写位置';const meta=node.querySelector('.task-meta'),path=folderPath(taskFolderId(task));const source=searching?(task.completedAt?'完成记录':task.state==='planned'?'行动计划':'收集箱'):['priority','unlocated'].includes(state.folderSelection[state.view])?(task.state==='planned'?'行动计划':'收集箱'):'';[source,path,task.date&&formatDate(task.date),task.time,task.attachment?'':`${task.duration}分钟`].filter(Boolean).forEach(v=>{const s=document.createElement('span');s.textContent=v;meta.appendChild(s)});const file=node.querySelector('.task-file');if(task.attachment){file.hidden=false;node.querySelector('.task-file-name').textContent=task.attachment.name||'未命名文件';node.querySelector('.task-file-type').textContent=task.attachment.type||'未知类型'}const notes=node.querySelector('.task-notes');notes.textContent=task.notes;notes.hidden=!task.notes;
    if(!searching&&state.view==='completed'&&state.batchDelete){const selected=state.selectedCompleted.has(task.id);card.classList.toggle('batch-selected',selected);complete.classList.add('batch-check');complete.classList.toggle('selected',selected);complete.title=selected?'取消选择':'选择此记录';complete.setAttribute('aria-label',complete.title);complete.onclick=()=>{selected?state.selectedCompleted.delete(task.id):state.selectedCompleted.add(task.id);render()};actions?actions.hidden=true:edit.hidden=true}else{complete.onclick=()=>{task.completedAt=task.completedAt?'':now();touch(task);save()};if(pin){pin.hidden=!!task.completedAt;pin.textContent=task.pinned?'取消置顶':'置顶';pin.title=pin.textContent;pin.setAttribute('aria-pressed',String(!!task.pinned));pin.classList.toggle('active',!!task.pinned);pin.onclick=()=>{task.pinned=!task.pinned;touch(task);save()}}edit.textContent=searching?'定位':'整理';edit.onclick=()=>searching?locateTask(task):openTask(task)}
    list.appendChild(node);
  }
  $('fileDrop').hidden=searching||state.view!=='inbox';
  $('quickCaptureForm').hidden=searching||state.view!=='inbox';
  $('todaySummary').hidden=searching||state.view!=='today';const todays=active.filter(t=>t.date===today());$('plannedMinutes').textContent=todays.reduce((n,t)=>n+Number(t.duration||0),0);$('remainingCount').textContent=todays.length;renderTimeline(todays);
}
function locateTask(task){state.searchQuery='';$('searchInput').value='';state.view=task.completedAt?'completed':task.state;if(state.view==='inbox'||state.view==='planned')state.folderSelection[state.view]=taskFolderId(task)||'all';render();requestAnimationFrame(()=>{const card=[...document.querySelectorAll('[data-task-id]')].find(node=>node.dataset.taskId===task.id);if(card){card.classList.add('located');card.scrollIntoView({behavior:'smooth',block:'center'});setTimeout(()=>card.classList.remove('located'),1800)}})}
function renderTimeline(tasks){$('todayDate').textContent=new Intl.DateTimeFormat('zh-CN',{month:'long',day:'numeric',weekday:'short'}).format(new Date());const list=$('timelineList');list.innerHTML='';const timed=tasks.filter(t=>t.time).sort(sortTasks);if(!timed.length){list.innerHTML='<p class="hint">还没有时间块。整理任务时设置开始时间。</p>';return}for(const t of timed){const div=document.createElement('div');div.className='time-block';div.innerHTML=`<time>${t.time}</time><h4></h4><p>${t.duration} 分钟</p>`;div.querySelector('h4').textContent=t.title;list.appendChild(div)}}

function updateTaskFolderOptions(selected=''){
  const scope=$('taskState').value,options=flattenFolders(scope),select=$('taskFolder');select.innerHTML='<option value="">未归类</option>';for(const {folder,depth} of options){const option=document.createElement('option');option.value=folder.id;option.textContent=`${'　'.repeat(depth)}${depth?'└ ':''}${folder.title}`;select.appendChild(option)}select.value=options.some(item=>item.folder.id===selected)?selected:'';
}
function updateTwoMinuteButton(){const task=state.tasks.find(item=>item.id===$('taskId').value),clarify=workflowFolder('clarify');$('twoMinuteTask').hidden=!task||!!task.completedAt||$('taskState').value!=='planned'||!clarify||!isFolderDescendant($('taskFolder').value,clarify.id)}
function openTask(task){
  const defaultState=state.view==='planned'?'planned':'inbox',t=task||{id:'',title:'',location:'',state:defaultState,folderId:selectedFolderId(defaultState),priority:'',date:'',time:'',duration:30,reminder:'',notes:''};$('dialogTitle').textContent=task?'整理任务':'记录任务';for(const [id,key] of [['taskId','id'],['taskTitle','title'],['taskLocation','location'],['taskState','state'],['taskPriority','priority'],['taskDate','date'],['taskTime','time'],['taskDuration','duration'],['taskReminder','reminder'],['taskNotes','notes']])$(id).value=t[key]||'';updateTaskFolderOptions(taskFolderId(t));$('deleteTask').hidden=!task;updateTwoMinuteButton();$('taskDialog').showModal();}
function weeklyReviewStats(){const active=activeTasks().filter(t=>!t.completedAt),day=today(),future=new Date(`${day}T00:00:00`);future.setDate(future.getDate()+14);const futureDay=dateValue(future),weekAgo=new Date(Date.now()-7*86400000),action=active.filter(t=>taskInWorkflowStage(t,'act'));return{collect:active.filter(t=>taskInWorkflowStage(t,'capture')).length,clarify:active.filter(t=>taskInWorkflowStage(t,'clarify')).length,action:action.length,unset:action.filter(t=>priorityRank(t)>4).length,overdue:action.filter(t=>t.date&&t.date<day).length,future:action.filter(t=>t.date&&t.date>=day&&t.date<=futureDay).length,completed:activeTasks().filter(t=>t.completedAt&&new Date(t.completedAt)>=weekAgo).length}}
function openWeeklyReview(){const stats=weeklyReviewStats(),checks=[...document.querySelectorAll('.review-check')];checks.forEach(check=>check.checked=false);$('reviewCollectText').textContent=stats.collect?`${stats.collect} 项待整理`:'已经清空';$('reviewClarifyText').textContent=stats.clarify?`${stats.clarify} 项待明确`:'已经清空';$('reviewActionText').textContent=stats.action?`${stats.action} 项可行动${stats.unset?`，${stats.unset} 项未定优先级`:''}${stats.overdue?`，${stats.overdue} 项日期已过去`:''}`:'暂无待行动内容';$('reviewFutureText').textContent=`未来14天有 ${stats.future} 项行动安排`;$('reviewCompletedText').textContent=`近7天完成 ${stats.completed} 项`;$('reviewSummary').textContent=stats.collect||stats.clarify||stats.unset||stats.overdue?`流程中有 ${stats.collect+stats.clarify+stats.unset+stats.overdue} 个位置值得检查。逐项确认后，再开始下一周。`:'流程清爽，可以放心投入下一周。';$('reviewProgress').textContent='已确认 0 / 5';$('reviewDialog').showModal()}
function updateFolderParentOptions(scope,folder,selected=''){const blocked=folder?descendantFolderIds(folder.id):new Set();blocked.add(QUICK_CAPTURE_FOLDER_ID);const options=flattenFolders(scope,blocked),select=$('folderParent');select.innerHTML='<option value="">无，作为顶层文件夹</option>';for(const {folder:optionFolder,depth} of options){const option=document.createElement('option');option.value=optionFolder.id;option.textContent=`${'　'.repeat(depth)}${depth?'└ ':''}${optionFolder.title}`;select.appendChild(option)}select.value=options.some(item=>item.folder.id===selected)?selected:''}
function openFolderDialog(folder){if(folder?.id===QUICK_CAPTURE_FOLDER_ID)return;const scope=folder?.scope||state.view,parentId=folder?.parentId||(!folder?selectedFolderId(scope):'');$('folderDialogTitle').textContent=folder?'管理文件夹':'新建文件夹';$('folderId').value=folder?.id||'';$('folderScope').value=scope;$('folderName').value=folder?.title||'';updateFolderParentOptions(scope,folder,parentId);$('confirmDeleteFolder').hidden=!folder;$('folderDialog').showModal();$('folderName').focus()}
function deleteCurrentFolder(){const folder=folderById($('folderId').value);if(!folder||folder.workflowStage||folder.id===QUICK_CAPTURE_FOLDER_ID||!confirm(`删除文件夹“${folder.title}”？其中的任务会移到“未归类”，子文件夹会上移一级。`))return;folder.deletedAt=now();touch(folder);for(const task of activeTasks().filter(t=>t.folderId===folder.id)){task.folderId='';touch(task)}for(const child of folders(folder.scope).filter(f=>f.parentId===folder.id)){child.parentId=folder.parentId||'';touch(child)}state.folderSelection[folder.scope]='all';$('folderDialog').close();save()}

document.querySelectorAll('.nav-item').forEach(b=>b.onclick=()=>{state.searchQuery='';$('searchInput').value='';state.view=b.dataset.view;state.batchDelete=false;state.selectedCompleted.clear();render()});$('newTaskButton').onclick=()=>openTask();
for(const stage of WORKFLOW_STAGES)document.querySelector(`[data-flow="${stage.key}"]`).onclick=()=>openWorkflowStage(stage.key);document.querySelector('[data-flow="review"]').onclick=openWeeklyReview;
document.querySelectorAll('[data-minutes]').forEach(button=>button.onclick=()=>{state.timeLimit=Number(button.dataset.minutes);render()});
$('searchInput').oninput=e=>{state.searchQuery=e.target.value.trim();state.batchDelete=false;state.selectedCompleted.clear();render()};$('clearSearch').onclick=()=>{state.searchQuery='';$('searchInput').value='';render();$('searchInput').focus()};
$('quickCaptureForm').onsubmit=e=>{e.preventDefault();recordQuickCapture()};
$('quickCaptureInput').oninput=()=>{$('quickCaptureStatus').textContent=''};
$('quickCaptureInput').onkeydown=e=>{if(e.key==='Enter'&&(e.isComposing||e.keyCode===229))e.preventDefault()};
$('startBatchDelete').onclick=()=>{state.batchDelete=true;state.selectedCompleted.clear();render()};
$('cancelBatchDelete').onclick=()=>{state.batchDelete=false;state.selectedCompleted.clear();render()};
$('selectAllCompleted').onclick=()=>{const completed=activeTasks().filter(t=>t.completedAt&&!isQuickCapture(t));if(completed.length&&state.selectedCompleted.size===completed.length)state.selectedCompleted.clear();else state.selectedCompleted=new Set(completed.map(t=>t.id));render()};
$('deleteSelectedCompleted').onclick=()=>{const count=state.selectedCompleted.size;if(!count||!confirm(`确定永久删除选中的 ${count} 条完成记录？`))return;for(const task of activeTasks().filter(t=>state.selectedCompleted.has(t.id))){task.deletedAt=now();touch(task)}state.batchDelete=false;state.selectedCompleted.clear();save()};
$('taskState').onchange=()=>{updateTaskFolderOptions();updateTwoMinuteButton()};$('taskFolder').onchange=updateTwoMinuteButton;
$('taskForm').onsubmit=e=>{e.preventDefault();const id=$('taskId').value;let task=state.tasks.find(t=>t.id===id);if(!task){const stamp=now();task={id:uid(),createdAt:stamp,updatedAt:stamp,completedAt:'',deletedAt:''};state.tasks.push(task)}for(const [id,key] of [['taskTitle','title'],['taskLocation','location'],['taskState','state'],['taskPriority','priority'],['taskDate','date'],['taskTime','time'],['taskDuration','duration'],['taskReminder','reminder'],['taskNotes','notes']])task[key]=$(id).value;task.folderId=$('taskFolder').value;const priority=Number(task.priority);task.priority=priority>=1&&priority<=4?priority:'';task.duration=Number(task.duration)||30;touch(task);$('taskDialog').close();save()};
$('newFolder').onclick=()=>openFolderDialog();$('renameFolder').onclick=()=>openFolderDialog(folderById(state.folderSelection[state.view]));$('deleteFolder').onclick=()=>openFolderDialog(folderById(state.folderSelection[state.view]));
$('folderForm').onsubmit=e=>{e.preventDefault();const name=$('folderName').value.trim(),scope=$('folderScope').value,id=$('folderId').value,parentId=$('folderParent').value;if(!name)return;let folder=folderById(id);if(folder?.workflowStage||folder?.id===QUICK_CAPTURE_FOLDER_ID||parentId===QUICK_CAPTURE_FOLDER_ID)return;if(id&&isFolderDescendant(parentId,id)){alert('不能把文件夹放入它自己或它的子文件夹。');return}if(folders(scope).some(f=>f.id!==id&&(f.parentId||'')===parentId&&f.title.toLocaleLowerCase('zh-CN')===name.toLocaleLowerCase('zh-CN'))){alert('同一个上级文件夹中已有这个名称。');return}if(folder){folder.title=name;folder.parentId=parentId;touch(folder)}else{const stamp=now();folder={id:uid(),kind:'folder',scope,parentId,title:name,createdAt:stamp,updatedAt:stamp,deletedAt:''};state.tasks.push(folder)}state.folderSelection[scope]=folder.id;$('folderDialog').close();save()};
$('confirmDeleteFolder').onclick=deleteCurrentFolder;
$('deleteTask').onclick=()=>{const task=state.tasks.find(t=>t.id===$('taskId').value);if(task&&confirm('确定删除这项任务？')){task.deletedAt=now();touch(task);$('taskDialog').close();save()}};
$('twoMinuteTask').onclick=()=>{const task=state.tasks.find(t=>t.id===$('taskId').value);if(!task)return;task.completedAt=now();touch(task);$('taskDialog').close();save()};
document.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>{b.closest('dialog').close();render()});$('taskDialog').oncancel=render;$('openSettings').onclick=()=>{updateBackupMessage();$('dataDialog').showModal()};
$('reviewStageAction').onclick=()=>{$('reviewDialog').close();openWorkflowStage('capture')};document.querySelectorAll('.review-check').forEach(check=>check.onchange=()=>{$('reviewProgress').textContent=`已确认 ${document.querySelectorAll('.review-check:checked').length} / 5`});$('completeReview').onclick=()=>{let review=state.tasks.find(t=>t.id===REVIEW_RECORD_ID&&t.kind==='system');if(!review){const stamp=now();review={id:REVIEW_RECORD_ID,kind:'system',title:'每周回顾',createdAt:stamp,updatedAt:stamp,deletedAt:''};state.tasks.push(review)}review.reviewedAt=now();touch(review);$('reviewDialog').close();save();$('saveStatus').textContent='本周回顾已完成'};
function createBackup(){const exportedAt=now(),text=JSON.stringify({version:2,exportedAt,tasks:state.tasks},null,2),fileName=`行动中枢备份-${today()}.json`;return{exportedAt,fileName,text,blob:new Blob([text],{type:'application/json'})}}
function finishBackup(exportedAt,status='备份已导出'){localStorage.setItem(LAST_BACKUP_KEY,exportedAt);updateBackupMessage();$('saveStatus').textContent=status}
function downloadBackup(backup){const a=document.createElement('a'),url=URL.createObjectURL(backup.blob);a.href=url;a.download=backup.fileName;a.click();setTimeout(()=>URL.revokeObjectURL(url),0)}
function openDrive(url){if(window.plus?.runtime?.openURL){plus.runtime.openURL(url);return}const opened=window.open('about:blank','_blank');if(opened){opened.opener=null;opened.location.href=url}else location.href=url}
function shareAndroidBackup(backup,name='文件管理或网盘'){
  const android=plus.android,activity=android.runtimeMainActivity(),NativeFile=android.importClass('java.io.File'),FileOutputStream=android.importClass('java.io.FileOutputStream'),OutputStreamWriter=android.importClass('java.io.OutputStreamWriter'),Intent=android.importClass('android.content.Intent'),FileProvider=android.importClass('androidx.core.content.FileProvider');
  // 只将本次备份交给用户选择的应用，并授予临时读取权限。
  const file=new NativeFile(android.invoke(activity,'getCacheDir'),`${Date.now()}-${backup.fileName}`),writer=new OutputStreamWriter(new FileOutputStream(file),'UTF-8');
  try{writer.write(backup.text);writer.flush()}finally{writer.close()}
  const uri=FileProvider.getUriForFile(activity,`${android.invoke(activity,'getPackageName')}.dc.fileprovider`,file);
  if(!uri)throw new Error('无法生成备份文件');
  const intent=new Intent(Intent.ACTION_SEND);intent.setType('application/json');intent.putExtra(Intent.EXTRA_STREAM,uri);intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
  android.invoke(activity,'startActivity',Intent.createChooser(intent,`请选择${name}保存备份`));
  $('saveStatus').textContent='请在分享面板中完成保存';
  $('backupMessage').textContent='备份已交给系统分享，请在目标应用确认保存；本应用无法确认网盘上传结果。';
}
async function backupToDrive(name,url){const backup=createBackup();if(window.plus?.os?.name==='Android'&&plus.android){try{shareAndroidBackup(backup,name)}catch{alert('暂时无法分享备份，请先使用网页版导出备份。')}return}if(typeof File==='function'&&navigator.share&&navigator.canShare){const file=new File([backup.blob],backup.fileName,{type:'application/json'});if(navigator.canShare({files:[file]})){try{await navigator.share({files:[file],title:'行动中枢备份',text:`请选择${name}或“存储到文件”保存备份`});finishBackup(backup.exportedAt,'备份已交给系统分享');return}catch(error){if(error?.name==='AbortError')return}}}downloadBackup(backup);finishBackup(backup.exportedAt,`备份已导出，请保存到${name}`);openDrive(url)}
$('exportData').onclick=async()=>{const backup=createBackup();if(window.plus?.os?.name==='Android'&&plus.android){try{shareAndroidBackup(backup)}catch{alert('暂时无法分享备份，请先使用网页版导出备份。')}return}if(typeof File==='function'&&navigator.share&&navigator.canShare){const file=new File([backup.blob],backup.fileName,{type:'application/json'});if(navigator.canShare({files:[file]})){try{await navigator.share({files:[file],title:'行动中枢备份',text:'请选择“存储到文件”或备份应用保存'});finishBackup(backup.exportedAt,'备份已交给系统分享');return}catch(error){if(error?.name==='AbortError')return}}}downloadBackup(backup);finishBackup(backup.exportedAt)};
$('backupBaidu').onclick=()=>backupToDrive('百度网盘','https://pan.baidu.com/');
$('backupQuark').onclick=()=>backupToDrive('夸克网盘','https://pan.quark.cn/');
$('importData').onchange=async e=>{try{const data=JSON.parse(await e.target.files[0].text());if(!Array.isArray(data.tasks))throw new Error();if(confirm(`将导入 ${data.tasks.length} 项任务并替换本机数据，是否继续？`)){state.tasks=data.tasks;normalizeTasks();save();$('dataDialog').close()}}catch{alert('备份文件无法识别。')}};
function updateBackupMessage(){const value=localStorage.getItem(LAST_BACKUP_KEY),message=$('backupMessage');if(!value){message.textContent='还没有导出备份，建议现在保存一份。';message.dataset.state='due';return}const date=new Date(value),days=Math.floor((Date.now()-date.getTime())/86400000);message.textContent=days>=7?`上次备份在 ${days} 天前，建议重新导出。`:`上次备份：${new Intl.DateTimeFormat('zh-CN',{year:'numeric',month:'long',day:'numeric'}).format(date)}`;message.dataset.state=days>=7?'due':'safe'}
function nativeReminderSignatures(){try{return JSON.parse(localStorage.getItem(NATIVE_REMINDERS_KEY)||'{}')}catch{return {}}}
function scheduleNativeNotifications(reminders){const scheduled=nativeReminderSignatures(),next={};for(const task of reminders){const delay=new Date(task.reminder)-Date.now(),signature=`${task.reminder}|${task.updatedAt}`;if(delay<=0)continue;next[task.id]=signature;if(scheduled[task.id]===signature)continue;plus.push.createMessage(task.title,JSON.stringify({kind:'task-reminder',taskId:task.id}),{title:'行动中枢',cover:false,sound:'system',delay:Math.ceil(delay/1000),when:new Date(task.reminder)})}localStorage.setItem(NATIVE_REMINDERS_KEY,JSON.stringify(next))}
async function scheduleNotifications(){const reminders=activeTasks().filter(task=>!task.completedAt&&task.reminder);if(window.plus?.push){if(!reminders.length){scheduleNativeNotifications([]);return}if(plus.os.name==='Android'&&plus.android?.requestPermissions&&!nativePermissionRequested){nativePermissionRequested=true;plus.android.requestPermissions(['android.permission.POST_NOTIFICATIONS'],()=>scheduleNativeNotifications(reminders),()=>scheduleNativeNotifications(reminders));return}scheduleNativeNotifications(reminders);return}for(const timer of notificationTimers.values())clearTimeout(timer);notificationTimers.clear();if(!reminders.length||!('Notification'in window))return;if(Notification.permission==='default')await Notification.requestPermission();if(Notification.permission!=='granted')return;for(const task of reminders){const delay=new Date(task.reminder)-Date.now();if(delay>0&&delay<2147483647)notificationTimers.set(task.id,setTimeout(()=>{new Notification('行动中枢',{body:task.title});notificationTimers.delete(task.id)},delay))}}
function enableNativeReminders(){if(!window.plus?.push)return;plus.push.addEventListener('click',message=>{try{const payload=typeof message.payload==='string'?JSON.parse(message.payload):message.payload,task=state.tasks.find(item=>item.id===payload?.taskId&&!item.deletedAt);if(task)locateTask(task)}catch{}},false);scheduleNotifications()}

function cloudConfig(){try{return JSON.parse(localStorage.getItem(CLOUD_KEY)||'null')}catch{return null}}
function cloudVersions(){try{return JSON.parse(localStorage.getItem(CLOUD_VERSIONS_KEY)||'{}')}catch{return {}}}
function pendingCloudTasks(){const versions=cloudVersions();return state.tasks.filter(task=>versions[task.id]!==task.updatedAt)}
function rememberCloudVersions(tasks,replace=false){const versions=replace?{}:cloudVersions();for(const task of tasks)versions[task.id]=task.updatedAt;localStorage.setItem(CLOUD_VERSIONS_KEY,JSON.stringify(versions))}
function setCloudStatus(badge,message){$('cloudBadge').textContent=badge;$('cloudMessage').textContent=message;$('saveStatus').textContent=badge;}
function initCloud(){
  const config=cloudConfig();$('cloudUrl').value=config?.url||'';$('cloudKey').value=config?.key||'';
  $('cloudDetails').open=!!config;
  $('syncActions').hidden=!config;
  if(config){const dirty=localStorage.getItem(CLOUD_DIRTY_KEY)==='1',recent=Date.now()-Number(config.lastSyncAt||0)<STARTUP_SYNC_INTERVAL;setCloudStatus('国内云已配置',dirty?'本机有修改，安静1分钟后合并同步。':recent?'最近已同步，无需重复调用云函数。':'正在检查其他设备的修改…');if(dirty)queueSync();else if(!recent)queueSync(500)}
  else{$('cloudBadge').textContent='未启用';$('cloudMessage').textContent='本机使用不需要配置。只有多个设备需要自动同步时，才启用这项高级功能。'}
}
$('generateCloudKey').onclick=()=>{const bytes=crypto.getRandomValues(new Uint8Array(24));$('cloudKey').value=btoa(String.fromCharCode(...bytes)).replaceAll('+','-').replaceAll('/','_').replaceAll('=','');alert('强同步密钥已生成，请点击“复制密钥”。部署云函数时需要填写同一密钥。')};
$('copyCloudKey').onclick=async()=>{const field=$('cloudKey'),key=field.value.trim();if(!key){alert('当前没有可复制的同步密钥。');return}try{await navigator.clipboard.writeText(key);alert('同步密钥已复制。')}catch{field.type='text';field.focus();field.select();if(document.execCommand('copy')){field.type='password';alert('同步密钥已复制。')}else alert('浏览器禁止自动复制，密钥已显示并选中，请长按复制。')}};
$('saveCloudConfig').onclick=async()=>{const url=$('cloudUrl').value.trim().replace(/\/$/,'');const key=$('cloudKey').value.trim();if(!/^https:\/\//.test(url)||key.length<24){alert('请填写 HTTPS 云函数地址，并使用至少24位的同步密钥。');return}localStorage.setItem(CLOUD_KEY,JSON.stringify({url,key,lastSyncAt:0}));localStorage.removeItem(CLOUD_VERSIONS_KEY);localStorage.setItem(CLOUD_DIRTY_KEY,'1');initCloud();await syncCloud()};
$('clearCloudConfig').onclick=()=>{if(confirm('停用本机云同步？本机任务不会被删除。')){localStorage.removeItem(CLOUD_KEY);localStorage.removeItem(CLOUD_VERSIONS_KEY);initCloud()}};
$('syncNow').onclick=()=>{state.syncRetries=0;clearTimeout(state.retryTimer);syncCloud()};
function queueSync(delay=AUTO_SYNC_DELAY){if(!cloudConfig()||!navigator.onLine)return;clearTimeout(state.syncTimer);clearTimeout(state.retryTimer);state.syncRetries=0;state.syncTimer=setTimeout(syncCloud,delay)}
function recordFiles(files,scope,folderId=''){const selected=[...files];if(!selected.length||!['inbox','planned'].includes(scope))return[];const folder=folderById(folderId),targetFolderId=folder?.scope===scope?folder.id:'',created=[];for(const file of selected){const stamp=now(),extension=file.name.includes('.')?file.name.split('.').pop().toUpperCase():'';const task={id:uid(),title:file.name,location:'',state:scope,folderId:targetFolderId,priority:'',date:'',time:'',duration:5,reminder:'',notes:'',attachment:{name:file.name,type:file.type||`${extension||'未知'}文件`},completedAt:'',deletedAt:'',createdAt:stamp,updatedAt:stamp};state.tasks.push(task);created.push(task)}save();return created}
function addInboxFiles(files){const created=recordFiles(files,'inbox',selectedFolderId('inbox'));if(!created.length)return;$('fileDropMessage').textContent=`已记录 ${created.length} 个文件；点击“整理”可填写位置`;$('inboxFiles').value='';if(created.length===1)openTask(created[0])}
function enableFolderFileDrop(button,folder){let dragDepth=0;const hasFiles=e=>[...(e.dataTransfer?.types||[])].includes('Files');button.addEventListener('dragenter',e=>{if(!hasFiles(e))return;e.preventDefault();dragDepth++;button.classList.add('drop-target')});button.addEventListener('dragover',e=>{if(!hasFiles(e))return;e.preventDefault();e.dataTransfer.dropEffect='copy'});button.addEventListener('dragleave',()=>{dragDepth=Math.max(0,dragDepth-1);if(!dragDepth)button.classList.remove('drop-target')});button.addEventListener('drop',e=>{if(!hasFiles(e))return;e.preventDefault();e.stopPropagation();dragDepth=0;button.classList.remove('drop-target');const created=recordFiles(e.dataTransfer.files,folder.scope,folder.id);if(created.length)$('saveStatus').textContent=`已放入“${folderPath(folder.id)}” · ${created.length} 个文件`})}
async function syncCloud(){
  const config=cloudConfig();if(state.syncing||!config||!navigator.onLine)return;clearTimeout(state.syncTimer);state.syncing=true;setCloudStatus('正在同步','正在通过国内云函数合并任务…');
  try{
    const changes=pendingCloudTasks(),revision=Number.isInteger(config.revision)?config.revision:null;
    const body=JSON.stringify({syncKey:config.key,protocol:2,revision,changes}),keepalive=new Blob([body]).size<=60000;
    const response=await fetch(config.url,{method:'POST',headers:{'content-type':'application/json'},body,keepalive});
    const result=await response.json().catch(()=>({error:'云函数返回内容无法识别'})),cloudError=typeof result.error==='string'?result.error:result.error?.message||result.message;if(!response.ok||result.success===false)throw new Error(cloudError||`云函数错误 ${response.status}`);if(result.full!==false&&!Array.isArray(result.tasks))throw new Error('云端没有返回有效任务数据');
    if(result.full!==false){state.tasks=result.tasks;normalizeTasks();persist();rememberCloudVersions(state.tasks,true)}else rememberCloudVersions(changes);state.syncRetries=0;clearTimeout(state.retryTimer);localStorage.setItem(CLOUD_KEY,JSON.stringify({...config,lastSyncAt:Date.now(),revision:Number(result.revision)||0}));localStorage.removeItem(CLOUD_DIRTY_KEY);render();scheduleNotifications();setCloudStatus('同步完成',`国内云 · ${new Intl.DateTimeFormat('zh-CN',{hour:'2-digit',minute:'2-digit',second:'2-digit'}).format(new Date())}${result.changed===false?' · 无变化，未写数据库':` · 已合并 ${changes.length} 项变化`}`);
  }catch(error){const message=error.message||'请检查网络、云函数地址和同步密钥。',resourceQuota=/resource exhausted|PrePayResourceExhausted/i.test(message),quota=resourceQuota||/今日.*额度.*用完|次日再同步/.test(message),transient=error instanceof TypeError||/fetch|network|网络|连接/i.test(message);if(quota){const next=new Date();next.setHours(24,1,0,0);const delay=next-Date.now();setCloudStatus(resourceQuota?'等待云额度恢复':'等待额度恢复',resourceQuota?'云函数免费资源额度已用完；修改已保存在本机，额度恢复后会自动重试。':'修改已保存在本机，将于次日 00:01 后自动重试。');clearTimeout(state.retryTimer);state.retryTimer=setTimeout(syncCloud,delay)}else if(transient&&state.syncRetries<3){const delays=[3000,10000,30000],delay=delays[state.syncRetries++];setCloudStatus('等待重试',`连接暂时中断，${delay/1000}秒后自动重试（${state.syncRetries}/3）`);clearTimeout(state.retryTimer);state.retryTimer=setTimeout(syncCloud,delay)}else setCloudStatus('同步失败',message)}finally{state.syncing=false}
}
function syncBeforeBackground(){if(localStorage.getItem(CLOUD_DIRTY_KEY)!=='1')return;state.syncRetries=0;clearTimeout(state.retryTimer);return syncCloud()}
function syncAfterResume(){const config=cloudConfig(),dirty=localStorage.getItem(CLOUD_DIRTY_KEY)==='1';if(dirty)return syncCloud();if(config&&Date.now()-Number(config.lastSyncAt||0)>=STARTUP_SYNC_INTERVAL)queueSync(500)}

const fileDrop=$('fileDrop');['dragenter','dragover'].forEach(type=>fileDrop.addEventListener(type,e=>{e.preventDefault();fileDrop.classList.add('dragging')}));['dragleave','drop'].forEach(type=>fileDrop.addEventListener(type,e=>{e.preventDefault();fileDrop.classList.remove('dragging')}));fileDrop.addEventListener('drop',e=>addInboxFiles(e.dataTransfer.files));$('inboxFiles').addEventListener('change',e=>addInboxFiles(e.target.files));
setupLocationAutocomplete('taskLocation','taskLocationMenu');
function isIosDevice(){return /iPhone|iPad|iPod/i.test(navigator.userAgent)||(navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1)}
function isStandalone(){return window.matchMedia?.('(display-mode: standalone)').matches||navigator.standalone===true}
function prepareInstallButton(){if(isIosDevice()&&!isStandalone()){$('installButton').textContent='添加到主屏幕';$('installButton').hidden=false}}
window.addEventListener('online',syncAfterResume);window.addEventListener('pagehide',syncBeforeBackground);window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();state.deferredPrompt=e;$('installButton').textContent='安装应用';$('installButton').hidden=false});window.addEventListener('appinstalled',()=>{$('installButton').hidden=true});$('installButton').onclick=async()=>{if(state.deferredPrompt){await state.deferredPrompt.prompt();state.deferredPrompt=null;$('installButton').hidden=true;return}if(isIosDevice())alert('请在 Safari 底部点击“分享”，再选择“添加到主屏幕”。')};
document.addEventListener('visibilitychange',()=>document.hidden?syncBeforeBackground():syncAfterResume());document.addEventListener('pause',syncBeforeBackground,false);document.addEventListener('resume',syncAfterResume,false);document.addEventListener('plusready',enableNativeReminders,false);if(normalizeTasks())localStorage.setItem(CLOUD_DIRTY_KEY,'1');if('serviceWorker'in navigator&&/^https?:$/.test(location.protocol))navigator.serviceWorker.register('sw.js');prepareInstallButton();render();scheduleNotifications();updateBackupMessage();initCloud();
